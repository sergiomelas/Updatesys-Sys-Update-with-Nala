#!/bin/bash

##################################################################
#              Pretty System Update - Refactored                 #
#            Developed by sergio melas  2021-26                  #
##################################################################

# --- Colors ---
C_BORDER='\e[96m'  # Cyan
C_TEXT='\e[97m'    # White
C_BOLD='\e[1m'
C_WARN='\e[93m'    # Yellow/Gold
C_RESET='\e[0m'

# --- Unified Nala-Style Header Function ---
draw_header() {
    local title="$1"
    local tip="$2"
    local width=79

    # 1. Top Line calculation (1 char shorter than bottom)
    local title_len=${#title}
    local right_bar_len=$((width - title_len - 5))

    echo -ne "${C_BORDER}┏━${C_TEXT}${C_BOLD} ${title} ${C_RESET}${C_BORDER}"
    for i in $(seq 1 $right_bar_len); do echo -n "━"; done
    echo -e "┓${C_RESET}"

    # 2. Middle Line (Empty or Tip)
    echo -ne "${C_BORDER}┃"
    if [ -z "$tip" ]; then
        for i in $(seq 1 $((width - 2))); do echo -n " "; done
    else
        local tip_len=${#tip}
        local padding=$((width - tip_len - 4))
        echo -ne "${C_RESET}  ${tip}"
        for i in $(seq 1 $padding); do echo -n " "; done
    fi
    echo -e "${C_BORDER}┃${C_RESET}"

    # 3. Bottom Line
    echo -ne "${C_BORDER}┗"
    for i in $(seq 1 $((width - 2))); do echo -n "━"; done
    echo -e "┛${C_RESET}"
}

# --- 1. Splash Screen ---
clear
draw_header "System update"
fastfetch -l none -s os:kernel:uptime:memory

# Get administrator rights & Set Directory
VAR=$0
DIR="$(dirname "${VAR}")"
cd "${DIR}"

# --- 2. Administrator Login ---
echo ""
draw_header "Login as administrator to update"
sudo ls >/dev/null
clear

# --- 3. Update Repositories ---
draw_header "Retriving updates"
sudo nala update

# --- 4. First Continue Prompt ---
echo -ne "${C_BORDER}\nDo you want to continue ? [Y/n]${C_RESET} "
read -r resp
if [ -z "$resp" ]; then resp="y"; fi

if [ "$resp" != "y" ] && [ "$resp" != "Y" ]; then
    clear
    draw_header "Exiting"
    sleep 1
    kill $(ps -ho ppid -p $(ps -ho ppid -p $$))
fi

# --- 5. Updating System ---
clear
draw_header "Updating system" "Use p to pin buglisted packages"
echo ""
sudo nala upgrade --autoremove --install-recommends --fix-broken --purge --no-update

# --- 6. Full Upgrade Check ---
echo -ne "${C_BORDER}\nDo you want to check for a full upgrade ? [y/N]${C_RESET} "
read -r resp
if [ -z "$resp" ]; then resp="n"; fi

if [ "$resp" != "n" ] && [ "$resp" != "N" ]; then
    clear
    draw_header "Checking full upgrade"
    sleep 1
    sudo nala upgrade --autoremove --install-recommends --fix-broken --purge --no-update --full
fi

# Exotic packages (Flatpak & Snap)
echo -e "\nUpdating Flatpaks:"
sudo flatpak update
echo -e "\nUpdating Snaps:"
sudo snap refresh

# --- 7. Cleanup Prompt ---
echo -ne "${C_BORDER}\nDo you want to cleaup apt cache, logs and old kernel modules ? [y/N]${C_RESET} "
read -r resp
if [ -z "$resp" ]; then resp="n"; fi

if [ "$resp" != "y" ] && [ "$resp" != "Y" ]; then
    clear
    draw_header "Exiting"
    sleep 1
    kill $(ps -ho ppid -p $(ps -ho ppid -p $$))
fi

# --- 8. Cleanup: Kernel Modules ---
clear
draw_header "System Cleanup: Kernel Modules"
echo -e "${C_BORDER}\nCleaning Kernel Modules:${C_RESET}"

modulestr=$(dpkg -S /lib/modules/* 2>&1 | grep "no path found" | awk '{ print $NF }')
if [ -z "$modulestr" ]; then
    echo "No Modules to Remove"
else
    for i in $modulestr; do
        if [[ $i == *'amd64'* ]]; then
            echo "Skipping Stock Kernel modules: $i"
        else
            echo "Removing Kernel Modules: $i"
            sudo rm -rf "$i"
        fi
    done
fi

echo -ne "${C_BORDER}\nPress any key to continue${C_RESET} "
read -n 1 -s -r

# --- 9. Cleanup: Package Cache & Configs ---
clear
draw_header "System Cleanup: Package Cache"
echo -e "\nCleaning Package Cache:"
sudo apt autoclean
sudo apt --purge autoremove

echo -e "\nCleaning Package old configs"
purgestr=$(COLUMNS=200 dpkg -l | grep "^rc" | awk '{print $2}')
if [ -n "$purgestr" ]; then
    echo "Cleanup packages configs"
    sudo dpkg --purge $purgestr
else
    echo "No packages config to Cleanup"
fi

echo -ne "${C_BORDER}\nPress any key to continue${C_RESET} "
read -n 1 -s -r

# --- 10. Cleanup: Logs ---
clear
draw_header "System Cleanup: Logs"
echo -e "\nCleaning Logs"
sudo journalctl --vacuum-size=100M
echo -ne "${C_BORDER}\nPress any key to continue${C_RESET} "
read -n 1 -s -r


# --- 11. Final Exit with Reboot Check ---
clear
if [ -f /var/run/reboot-required ]; then
    draw_header "Update Finished" "ATTENTION: REBOOT REQUIRED"
else
    draw_header "Update Finished" "System up to date. No reboot needed."
fi

echo -ne "${C_BORDER}\nPress any key to exit${C_RESET} "
read -n 1 -s -r

# Closing the Konsole window
kill $(ps -ho ppid -p $(ps -ho ppid -p $$))
exit 0
