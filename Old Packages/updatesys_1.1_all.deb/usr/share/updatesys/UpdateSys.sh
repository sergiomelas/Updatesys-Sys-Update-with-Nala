#!/bin/bash

##################################################################
#               Pretty System Update - Precision                 #
#            Developed by sergio melas  2021-26                  #
##################################################################

# --- Colors ---
C_BORDER='\e[96m'; C_TEXT='\e[97m'; C_BOLD='\e[1m'; C_WARN='\e[93m'
C_PROMPT='\e[92m'; C_NALA_G='\e[32m'; C_NALA_R='\e[31m'; C_RESET='\e[0m'

# --- 1. Progress Engine (12 High-Level Steps) ---
STEP=1
TOTAL_STEPS=12

draw_progress() {
    local width=79
    local percent=$(( STEP * 100 / TOTAL_STEPS ))
    local filled=$(( STEP * width / TOTAL_STEPS ))
    local empty=$(( width - filled ))

    # Nala Style Bar
    echo -ne "${C_NALA_G}"
    for i in $(seq 1 $filled); do echo -n "━"; done
    echo -ne "${C_NALA_R}"
    for i in $(seq 1 $empty); do echo -n "━"; done
    echo -e "${C_RESET}\n Progress: ${percent}%"
}

draw_header() {
    local title="$1"; local tip="$2"; local width=79
    local title_len=${#title}
    local bar_len=$((width - title_len - 5))

    echo -ne "${C_BORDER}┏━${C_TEXT}${C_BOLD} ${title} ${C_RESET}${C_BORDER}$(printf '━%.0s' $(seq 1 $bar_len))┓\n"
    echo -ne "┃${C_RESET}  ${tip}$(printf ' %.0s' $(seq 1 $((width - ${#tip} - 4))))${C_BORDER}┃\n"
    echo -e "┗$(printf '━%.0s' $(seq 1 $((width - 2))))┛${C_RESET}"
}

# The "Rule": Every step that starts with CLEAR must have this pause before it
wait_user() {
    echo -ne "\n${C_WARN}Press any key to continue...${C_RESET} "
    read -n 1 -s -r
    ((STEP++))
}

# --- 2. Silent Check (Step 1) ---
clear
draw_progress
draw_header "Initial Check" "Analyzing system repositories silently..."
sudo nala update 2>&1 | tee /tmp/up_check.txt

# Logic Analysis
APT_UP=true; grep -qE "[1-9][0-9]* packages can be upgraded" /tmp/up_check.txt && APT_UP=false
FP_UP=true; command -v flatpak &>/dev/null && flatpak update --dry-run 2>&1 | grep -iqE "ID|Installing|Updating" && FP_UP=false
SNAP_UP=true; command -v snap &>/dev/null && ! sudo snap refresh --list 2>&1 | grep -iqE "up to date|no updates" && SNAP_UP=false
rm -f /tmp/up_check.txt

wait_user # Moves to Step 2

# --- 3. Update Branch (Steps 2-5) ---
clear; draw_progress
if [ "$APT_UP" = true ] && [ "$FP_UP" = true ] && [ "$SNAP_UP" = true ]; then
    draw_header "Status" "System is already fully up to date."
    STEP=5 # Jump past the update steps to the cleanup decision
    wait_user
else
    draw_header "Update Pending" "New packages found"
    # APT
    if [ "$APT_UP" = false ]; then
        echo -ne "\n${C_PROMPT}Install APT updates? [Y/n]${C_RESET} "; read -r resp
        if [[ ! $resp =~ ^[Nn]$ ]]; then
            sudo nala upgrade --autoremove --install-recommends --fix-broken --purge --no-update
        fi
    fi
    ((STEP++)) # Step 3
    # Flatpak
    if [ "$FP_UP" = false ]; then
        echo -e "\n${C_BOLD}Updating Flatpaks...${C_RESET}"; sudo flatpak update -y
    fi
    ((STEP++)) # Step 4
    # Snap
    if [ "$SNAP_UP" = false ]; then
        echo -e "\n${C_BOLD}Updating Snaps...${C_RESET}"; sudo snap refresh
    fi
    ((STEP++)) # Step 5
    wait_user
fi

# --- 4. Cleanup Decision (Step 6) ---
clear; draw_progress
draw_header "Maintenance" "Check for cleanup?"
echo -ne "\n${C_PROMPT}Run system cleanup? [y/N]${C_RESET} "; read -r resp
if [[ ! $resp =~ ^[Yy]$ ]]; then
    STEP=10 # Jump past the 4 cleanup phases
    wait_user
else
    ((STEP++)) # Step 7
    # 7.1 Kernel Modules
    clear; draw_progress
    draw_header "Cleanup 1/4" "Removing unused kernel modules"
    modulestr=$(dpkg -S /lib/modules/* 2>&1 | grep "no path found" | awk '{ print $NF }')
    if [ -z "$modulestr" ]; then echo "No modules to remove."; else
        for i in $modulestr; do [[ $i != *'amd64'* ]] && sudo rm -rf "$i" || echo "Skipping stock: $i"; done
    fi
    wait_user # Step 8

    # 7.2 Cache
    clear; draw_progress
    draw_header "Cleanup 2/4" "Package Cache"
    sudo apt autoclean; sudo apt --purge autoremove
    wait_user # Step 9

    # 7.3 Configs
    clear; draw_progress
    draw_header "Cleanup 3/4" "Old Configurations"
    purgestr=$(COLUMNS=200 dpkg -l | grep "^rc" | awk '{print $2}')
    [ -n "$purgestr" ] && sudo dpkg --purge $purgestr || echo "No residual configs found."
    wait_user # Step 10

    # 7.4 Logs
    clear; draw_progress
    draw_header "Cleanup 4/4" "System Logs"
    sudo journalctl --vacuum-size=100M
    wait_user # Step 11
fi

# --- 5. Final Results (Step 11) ---
clear; draw_progress
if [ -f /var/run/reboot-required ]; then
    draw_header "Complete" "REBOOT REQUIRED"
    echo -ne "\n${C_WARN}Reboot now? [y/N]${C_RESET} "; read -r resp
    [[ $resp =~ ^[Yy]$ ]] && sudo reboot
else
    draw_header "Complete" "System up to date. No reboot needed."
    wait_user # Step 12
fi

# --- 6. Exit ---
clear; STEP=$TOTAL_STEPS; draw_progress
draw_header "Goodbye" "Process complete."
sleep 1
kill $(ps -ho ppid -p $(ps -ho ppid -p $$)) 2>/dev/null
exit 0
