#!/bin/bash
            ##################################################################
            #                     Pretty System Update                       #
            #              Developed by sergio melas  2021-23                #
            ##################################################################

#splash screen
echo -e "\e[96m "
echo -e "┏━\e[97m\e[1m System update\e[0m \e[96m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"
echo -e "┃                                                                                       ┃"
echo -e "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"
echo -e "\e[0m "
echo '  '
fastfetch --logo '/home/sergio/Others/Interface/Icons Debian Menu/Debian nf sid.png'

echo  "T64 libraries migration to go:"
apt-cache search --names-only t64 | wc -l
echo -e "\e[96m "
echo "Press any key to continue"
echo -e "\e[0m "
read resp

clear

#Get administrator rights
VAR=$0
DIR="$(dirname "${VAR}")"
cd  "${DIR}"


echo -e "\e[96m "
echo -e "┏━\e[97m\e[1m Login as administrator to update\e[0m \e[96m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"
echo -e "┃                                                                   ┃"
echo -e "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"
echo -e "\e[0m "
sudo ls >/dev/null
echo  ""
# sudo rm /etc/apt/preferences.d/apt-listbugs #remove pins of apt-listbugs
clear



#update repositories
echo -e "\e[96m "
echo -e "┏━\e[97m\e[1m Retriving updates\e[0m \e[96m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"
echo -e "┃                                                                                       ┃"
echo -e "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"
echo -e "\e[0m "

sudo nala update
#sudo apt-get update

#Update system
echo -e "\e[96m "
echo "Do you want to continue ? [Y/n]"
echo -e "\e[0m "
read resp

if   [ -z "$resp" ]
then
 resp="y"
fi

if   [ $resp != 'y' ] && [ $resp != 'Y' ]
then
  echo -e "\e[96m "
  echo -e "┏━\e[97m\e[1m Exiting\e[0m \e[96m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"
  echo -e "┃                                                                   ┃"
  echo -e "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"
  echo -e "\e[0m "
  sleep 1
  kill $(ps -ho ppid -p $(ps -ho ppid -p $$))
fi


clear
echo -e "\e[96m "
echo -e "┏━\e[97m\e[1m Updating system\e[0m \e[96m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"
echo -e "┃  Use ""p"" to pin buglisted packages                                                      ┃"
echo -e "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"
echo -e "\e[0m "

sudo nala upgrade --autoremove --install-recommends --fix-broken --purge  --no-update
#sudo apt-get upgrade

echo -e "\e[96m "
echo "Do you want to check for a full upgrade ? [y/N]"
echo -e "\e[0m "

read resp


if   [ -z "$resp" ]
then
 resp="n"
fi

if   [ $resp != 'n' ] && [ $resp != 'N' ]
then
  clear
  echo -e "\e[96m "
  echo -e "┏━\e[97m\e[1m Checking full upgrade\e[0m \e[96m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"
  echo -e "┃                                                                   ┃"
  echo -e "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"
  echo -e "\e[0m "
  sleep 1
  sudo nala upgrade --autoremove --install-recommends --fix-broken --purge  --no-update --full
  #sudo apt-get dist-upgrade
  #sudo apt-get  install $(apt-show-versions | grep experimental | grep upgradeable | cut -d '/' -f -1 | xargs | sed -e 's/ /\/experimental /g')
fi

#Update exotic packages
echo " "
echo "Updating Flatpaks:"
sudo flatpak update
echo " "
echo "Updating Snaps:"
sudo snap refresh
echo " "




echo -e "\e[96m "
echo "Do you want to cleaup apt cache, logs and old kernel modules ? [y/N]"
echo -e "\e[0m "

read resp


if   [ -z "$resp" ]
then
 resp="n"
fi

if   [ $resp != 'y' ] && [ $resp != 'Y' ]
then
  echo -e "\e[96m "
  echo -e "┏━\e[97m\e[1m Exiting\e[0m \e[96m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"
  echo -e "┃                                                                   ┃"
  echo -e "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"
  echo -e "\e[0m "
  sleep 1
  kill $(ps -ho ppid -p $(ps -ho ppid -p $$))
fi


clear

echo -e "\e[96m "
echo -e "┏━\e[97m\e[1m System Cleanup:  Kernel Modules\e[0m \e[96m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"
echo -e "┃                                                                                       ┃"
echo -e "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"
echo -e "\e[0m "

echo -e "\e[96m "
echo "Cleaning Kernel Modules:"
echo -e "\e[0m "

modulestr=$(dpkg -S /lib/modules/* 2>&1 | grep "no path found matching pattern" | awk '{ print $NF }' | tr "\n" " ")
if [ -z "$modulestr" ]
then
  echo "No Modules to Remove"
else
  modulearr=($modulestr) #Convert list of string to vector of string
  for i in "${modulearr[@]}"
  do
  :
  if [[ $i = *'amd64'* ]]; then #if is stock skip
    echo "Skipping Stock Kernel modules": $i
  else
    echo "Removing Kernel Modules": $i
    sudo rm -r   $i
  fi
  done
fi

echo -e "\e[96m "
echo "Press any key to continue"
echo -e "\e[0m "

read resp

clear

echo -e "\e[96m "
echo -e "┏━\e[97m\e[1m System Cleanup: Package Cache \e[0m \e[96m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"
echo -e "┃                                                                                       ┃"
echo -e "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"
echo -e "\e[0m "

echo Cleaning Package Cache:
#apt
sudo apt autoclean
sudo apt --purge autoremove
#old configs


echo " "
echo Cleaning Package old configs
purgestr=$(COLUMNS=200 dpkg -l | grep "^rc" | tr -s ' ' | cut -d ' ' -f 2)
if [ -z "$purgestr" ]
then
  echo "No packages config  to Cleanup"
else
  echo "Cleanup packages configs"
  sudo dpkg --purge  $(COLUMNS=200 dpkg -l | grep "^rc" | tr -s ' ' | cut -d ' ' -f 2)
fi


echo -e "\e[96m "
echo "Press any key to continue"
echo -e "\e[0m "

read resp

clear

echo -e "\e[96m "
echo -e "┏━\e[97m\e[1m System Cleanup: Logs \e[0m \e[96m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"
echo -e "┃                                                                                       ┃"
echo -e "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"
echo -e "\e[0m "
echo Clening Logs
sudo journalctl --vacuum-size=100M



echo -e "\e[96m "
echo -e "┏━\e[97m\e[1m Press any key to exit\e[0m \e[96m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"
echo -e "┃                                                                   ┃"
echo -e "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"
echo -e "\e[0m "
read resp

kill $(ps -ho ppid -p $(ps -ho ppid -p $$))


