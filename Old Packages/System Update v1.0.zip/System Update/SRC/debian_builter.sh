#!/bin/bash

# --- Configuration ---
PKG_NAME="updatesys"
PKG_VER="1.1.0"
BUILD_DIR="build_workspace"

# --- Source Files from your Payload folder ---
MAIN_LOGIC="UpdateSys.sh"
LAUNCHER="UpdateSys_Laucher.sh"
DESKTOP_FILE="Sys Update.desktop"
ICON_FILE="updatesys.png"

echo "📦 Start building the Debian package from Payload..."

# 1. Clean and create structure
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR/DEBIAN"
mkdir -p "$BUILD_DIR/usr/local/bin"
mkdir -p "$BUILD_DIR/usr/share/updatesys"
mkdir -p "$BUILD_DIR/usr/share/applications"
mkdir -p "$BUILD_DIR/usr/share/icons/hicolor/scalable/apps"

# 2. Install logic and launcher binary
# We rename the launcher to 'updatesys' so you can just type it in terminal
cp "$MAIN_LOGIC" "$BUILD_DIR/usr/share/updatesys/UpdateSys.sh"
cp "$LAUNCHER" "$BUILD_DIR/usr/local/bin/updatesys"
chmod +x "$BUILD_DIR/usr/share/updatesys/UpdateSys.sh"
chmod +x "$BUILD_DIR/usr/local/bin/updatesys"

# 3. Install Desktop Entry and Icon
cp "$DESKTOP_FILE" "$BUILD_DIR/usr/share/applications/updatesys.desktop"
cp "$ICON_FILE" "$BUILD_DIR/usr/share/icons/hicolor/scalable/apps/updatesys.png"

# 4. Create the Debian Control file
cat <<EOF > "$BUILD_DIR/DEBIAN/control"
Package: $PKG_NAME
Version: $PKG_VER
Section: utils
Priority: optional
Architecture: all
Maintainer: Sergio Melas <sergiomelas@gmail.com>
Depends: nala, fastfetch, flatpak
Recommends: konsole | gnome-terminal | xfce4-terminal
Description: Pretty System Update
 A professional, Nala-inspired system updater.
 features a color-morphing progress bar and universal terminal support.
EOF

# 5. Create the Post-Installation script
cat <<EOF > "$BUILD_DIR/DEBIAN/postinst"
#!/bin/bash
# Fix system-wide permissions
chmod +x /usr/share/updatesys/UpdateSys.sh
chmod +x /usr/local/bin/updatesys
# Refresh system caches so the icon appears in the menu immediately
gtk-update-icon-cache -f /usr/share/icons/hicolor >/dev/null 2>&1
update-desktop-database /usr/share/applications >/dev/null 2>&1
echo "################################################"
echo "# UpdateSys V1.1 installato con successo!      #"
echo "# Cerca 'Update System' nel menu o digita      #"
echo "# 'updatesys' nel terminale.                   #"
echo "################################################"
EOF
chmod 755 "$BUILD_DIR/DEBIAN/postinst"

# 6. Build the package
echo "🏗️  Compiling .deb..."
dpkg-deb --build "$BUILD_DIR" "${PKG_NAME}_${PKG_VER}_all.deb"

# 7. Cleanup
rm -rf "$BUILD_DIR"
echo "✅ Done! Final file: ${PKG_NAME}_${PKG_VER}_all.deb"
